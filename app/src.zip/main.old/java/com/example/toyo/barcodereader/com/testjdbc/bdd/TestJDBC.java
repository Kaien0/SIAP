package com.example.toyo.barcodereader.com.testjdbc.bdd;

/**
 * Created by bashark on 11/09/2016.
 */
import java.util.ArrayList;
import java.util.List;

//import javax.servlet.http.HttpServletRequest;
//
//
//public class TestJDBC {
//
//    private List<String> messages = new ArrayList<String>();
//
//    public List<String> executerTests( HttpServletRequest request ) {
//
//        /* Ici, nous placerons le code de nos manipulations */
//
//        /* ... */
//        return messages;
//    }
//}